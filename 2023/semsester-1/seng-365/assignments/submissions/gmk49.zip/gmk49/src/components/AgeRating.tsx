export const ageRatings = ['G', 'PG', 'M', 'R13', 'R16', 'R18', 'TBC'] as const

export type AgeRating = (typeof ageRatings)[number]

export const getColor = (ageRating: AgeRating) => {
	switch (ageRating) {
		case 'G': {
			return 'bg-green-600/90'
		}
		case 'PG': {
			return 'bg-green-600/90'
		}
		case 'M': {
			return 'bg-rose-600/90'
		}
		case 'R13': {
			return 'bg-amber-500/90'
		}
		case 'R16': {
			return 'bg-rose-600/90'
		}
		case 'R18': {
			return 'bg-rose-600/90'
		}
		case 'TBC': {
			return 'bg-zinc-800/90'
		}
	}
}
