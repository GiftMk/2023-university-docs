import React from 'react'

interface AuthContextProps {
	authedUserId: string | null
	authedUserToken: string | null
	authedUserEmail: string | null
	authedUserPassword: string | null
	updateAuth: (
		userId: string | null,
		userToken: string | null,
		userEmail: string | null,
		userPassword: string | null
	) => void
}

export const AuthContext = React.createContext<AuthContextProps>({
	authedUserId: null,
	authedUserToken: null,
	authedUserEmail: null,
	authedUserPassword: null,
	updateAuth: () => {}
})

interface AuthProviderProps {
	children: React.ReactNode
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
	const [authedUserId, setAuthedUserId] = React.useState<string | null>(null)
	const [authedUserToken, setAuthedUserToken] = React.useState<string | null>(null)
	const [authedUserEmail, setAuthedUserEmail] = React.useState<string | null>(null)
	const [authedUserPassword, setAuthedUserPassword] = React.useState<string | null>(null)

	React.useEffect(() => {
		const storedUserId = localStorage.getItem('authedUserId')
		const storedUserToken = localStorage.getItem('authedUserToken')
		const storedUserEmail = localStorage.getItem('authedUserEmail')
		const storedUserPassword = localStorage.getItem('authedUserPassword')

		if (storedUserId && storedUserToken) {
			setAuthedUserId(storedUserId)
			setAuthedUserToken(storedUserToken)
			setAuthedUserEmail(storedUserEmail)
			setAuthedUserPassword(storedUserPassword)
		}
	}, [])

	const updateAuth = (
		userId: string | null,
		userToken: string | null,
		userEmail: string | null,
		userPassword: string | null
	) => {
		if (userId && userToken && userEmail && userPassword) {
			localStorage.setItem('authedUserId', userId)
			localStorage.setItem('authedUserToken', userToken)
			localStorage.setItem('authedUserEmail', userEmail)
			localStorage.setItem('authedUserPassword', userPassword)
		} else {
			localStorage.removeItem('authedUserId')
			localStorage.removeItem('authedUserToken')
			localStorage.removeItem('authedUserEmail')
			localStorage.removeItem('authedUserPassword')
		}
		setAuthedUserId(userId)
		setAuthedUserToken(userToken)
		setAuthedUserEmail(userEmail)
		setAuthedUserPassword(userPassword)
	}

	return (
		<AuthContext.Provider value={{ authedUserId, authedUserToken, authedUserEmail, authedUserPassword, updateAuth }}>
			{children}
		</AuthContext.Provider>
	)
}
