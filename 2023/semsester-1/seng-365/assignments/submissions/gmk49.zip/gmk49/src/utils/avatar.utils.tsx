import Avatar from 'boring-avatars'

const getDefaultAvatar = (name: string) => {
	return (
		<Avatar size={'100%'} name={name} variant='beam' colors={['#FFF5DE', '#FFC83A', '#E8E8E8', '#F0AB3D', '#DD682A']} />
	)
}

export default getDefaultAvatar
