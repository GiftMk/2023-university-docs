import React from 'react'
import { AuthContext } from '../../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import useUser from '../../hooks/useUser'
import MainLayout from '../../layouts/MainLayout'
import { API_URL } from '../../api/constants'
import * as Avatar from '@radix-ui/react-avatar'
import * as Dialog from '@radix-ui/react-dialog'
import getDefaultAvatar from '../../utils/avatar.utils'
import EditForm from './EditForm'
import axios from 'axios'

interface EditDialogProps {
	id: string
	password: string
	token: string
}

const EditDialog = ({ id, password, token }: EditDialogProps) => {
	const [isOpen, setIsOpen] = React.useState(false)

	return (
		<Dialog.Root open={isOpen} onOpenChange={setIsOpen}>
			<Dialog.Trigger className='px-3 py-1 rounded-3xl text-white bg-accent hover:brightness-[96%] transition ease-in-out duration-200'>
				Edit
			</Dialog.Trigger>
			<Dialog.Portal>
				<Dialog.Overlay className='bg-black/70 fixed inset-0 z-10 fade' />
				<Dialog.Content className='fixed top-[50%] left-[50%] w-[80vw] sm:w-[60vw] md:w-[50vw] lg:w-[40vw] xl:w-[30vw] translate-x-[-50%] translate-y-[-50%] rounded-3xl bg-white p-7 z-50 shadow-lg'>
					<Dialog.Close className='absolute rounded-3xl top-2.5 right-2.5 p-2 hover:bg-zinc-200/50 transition duration-200 ease-out'>
						<svg
							xmlns='http://www.w3.org/2000/svg'
							fill='none'
							viewBox='0 0 24 24'
							strokeWidth={1.5}
							stroke='currentColor'
							className='w-6 h-6'
						>
							<path strokeLinecap='round' strokeLinejoin='round' d='M6 18L18 6M6 6l12 12' />
						</svg>
					</Dialog.Close>
					<EditForm id={id} password={password} setIsSuccessful={() => setIsOpen(false)} token={token} />
				</Dialog.Content>
			</Dialog.Portal>
		</Dialog.Root>
	)
}

const Profile = () => {
	const { authedUserId, authedUserToken, authedUserEmail, authedUserPassword, updateAuth } =
		React.useContext(AuthContext)
	const [hasProfilePicture, setHasProfilePicture] = React.useState(false)

	const user = useUser(authedUserId || '')
	const navigate = useNavigate()

	const handleProfilePictureChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		if (event.target.files && event.target.files.length > 0) {
			const selectedFile = event.target.files[0]
			const formData = new FormData()
			formData.append('image', selectedFile, selectedFile.name)

			let contentType = ''
			if (selectedFile.type === 'image/png') {
				contentType = 'image/png'
			} else if (selectedFile.type === 'image/jpeg' || selectedFile.type === 'image/jpg') {
				contentType = 'image/jpeg'
			} else if (selectedFile.type === 'image/gif') {
				contentType = 'image/gif'
			}

			axios
				.put(API_URL + '/users/' + authedUserId + '/image', selectedFile, {
					headers: {
						'X-Authorization': authedUserToken,
						'Content-Type': contentType
					}
				})
				.then(() => window.location.reload())
			setHasProfilePicture(true)
		}
	}

	const handleRemove = () => {
		axios.delete(API_URL + '/users/' + authedUserId + '/image', {
			headers: {
				'X-Authorization': authedUserToken
			}
		})
		setHasProfilePicture(false)
	}

	const handleLogout = () => {
		axios
			.post(API_URL + '/users/logout', null, {
				headers: {
					'X-Authorization': authedUserToken
				}
			})
			.then(() => {
				updateAuth(null, null, null, null)
				navigate('/login')
			})
	}

	React.useEffect(() => {
		if (!authedUserId) {
			navigate('/login')
		}
	}, [authedUserId])

	if (user && authedUserId && authedUserEmail && authedUserPassword && authedUserToken) {
		return (
			<MainLayout>
				<div className='flex flex-col gap-2 w-full items-center p-5 bg-white rounded-3xl'>
					<Avatar.Root className='w-20 h-20 flex items-center justify-center overflow-hidden rounded-full'>
						<Avatar.Image
							src={`${API_URL}/users/${authedUserId}/image`}
							onLoad={() => setHasProfilePicture(true)}
							onError={() => setHasProfilePicture(false)}
							key={Date.now()}
							alt='director-profile-picture'
							className='aspect-square object-cover'
							loading='eager'
						/>
						<Avatar.Fallback className='AvatarFallback fade' delayMs={100}>
							{getDefaultAvatar(`${user.firstName} ${user.lastName}`)}
						</Avatar.Fallback>
					</Avatar.Root>
					{hasProfilePicture ? (
						<button
							onClick={handleRemove}
							className='fade py-1 px-3 rounded-3xl bg-red-300/80 hover:bg-red-400/80 text-red-950 transition duration-200 ease-out'
						>
							Remove
						</button>
					) : (
						<label className='fade flex flex-col justify-center items-center bg-white drop-shadow-md px-5 py-2 rounded-full cursor-pointer transition-all duration-200 ease-out hover:brightness-[98%]'>
							<input
								type='file'
								id='profilePicture'
								accept='.jpeg, .jpg, .png, .gif'
								className='hidden'
								onChange={handleProfilePictureChange}
							/>
							<p className='text-sm'>Upload a photo</p>
						</label>
					)}
					<div className='text-center mt-5 mb-2'>
						<h1 className='capitalize font-medium text-xl'>
							{user.firstName} {user.lastName}
						</h1>
						<p className='text-sm text-zinc-600 py-1'>{authedUserEmail}</p>
					</div>
					<EditDialog id={authedUserId} password={authedUserPassword} token={authedUserToken} />
				</div>
				<div className='flex flex-col gap-2 w-full items-center p-5 bg-white rounded-3xl'>
					<button
						onClick={handleLogout}
						className='py-1 px-3 rounded-3xl bg-red-300/80 hover:bg-red-400/80 text-red-950 transition duration-200 ease-out'
					>
						Logout
					</button>
				</div>
			</MainLayout>
		)
	}
	return null
}

export default Profile
