import { Link } from 'react-router-dom'
import MainLayout from '../layouts/MainLayout'
import * as Form from '@radix-ui/react-form'
import React from 'react'
import axios from 'axios'
import { API_URL } from '../api/constants'
import { AuthContext } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import { LoginResponse } from '../api/Auth'
import getDefaultAvatar from '../utils/avatar.utils'

const MIN_PASSWORD_SIZE = 6

const Register = () => {
	const [firstName, setFirstName] = React.useState('')
	const [lastName, setLastName] = React.useState('')
	const [email, setEmail] = React.useState('')
	const [password, setPassword] = React.useState('')
	const [profilePicture, setProfilePicture] = React.useState<File | null>(null)

	const [registerError, setRegisterError] = React.useState(false)
	const [emailAlreadyExists, setEmailAlreadyExists] = React.useState(false)
	const [passwordIsInvalid, setPasswordIsInvalid] = React.useState(false)

	const { authedUserId, updateAuth } = React.useContext(AuthContext)
	const navigate = useNavigate()

	React.useEffect(() => {
		setEmailAlreadyExists(false)
	}, [email])

	React.useEffect(() => {
		if (password && password.length < MIN_PASSWORD_SIZE) {
			setPasswordIsInvalid(true)
		} else {
			setPasswordIsInvalid(false)
		}
	}, [password])

	React.useLayoutEffect(() => {
		if (authedUserId) {
			navigate('/profile')
		}
	}, [authedUserId])

	const handleProfilePictureChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		if (event.target.files && event.target.files.length > 0) {
			const selectedFile = event.target.files[0]
			setProfilePicture(selectedFile)
		}
	}

	const handleRemove = () => {
		setProfilePicture(null)
	}

	const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault()
		const data = {
			firstName: firstName,
			lastName: lastName,
			email: email,
			password: password
		}

		if (emailAlreadyExists || passwordIsInvalid) return

		// needs refactoring!
		axios.post(API_URL + '/users/register', data).then(
			() => {
				axios.post(API_URL + '/users/login', { email: email, password: password }).then(
					// log the user in
					response => {
						const loginResponse: LoginResponse = response.data
						updateAuth(loginResponse.userId, loginResponse.token, email, password)
						// set profile picture if given
						if (profilePicture) {
							const formData = new FormData()
							formData.append('image', profilePicture, profilePicture.name)

							let contentType = ''
							if (profilePicture.type === 'image/png') {
								contentType = 'image/png'
							} else if (profilePicture.type === 'image/jpeg' || profilePicture.type === 'image/jpg') {
								contentType = 'image/jpeg'
							} else if (profilePicture.type === 'image/gif') {
								contentType = 'image/gif'
							}
							axios.put(API_URL + '/users/' + loginResponse.userId + '/image', profilePicture, {
								headers: {
									'X-Authorization': loginResponse.token,
									'Content-Type': contentType
								}
							})
						}
						// go to the profile page
						navigate('/profile')
					},
					() => {
						setRegisterError(true)
					}
				)
			},
			error => {
				if (error.response) {
					if (error.response.status === 403) {
						setEmailAlreadyExists(true)
					} else if (error.response.status === 400) {
						setPasswordIsInvalid(true)
					} else {
						setRegisterError(true)
					}
				}
			}
		)
	}

	if (authedUserId) return null

	return (
		<MainLayout>
			<div className='w-full flex flex-col items-center justify-center'>
				<div className='flex gap-4 items-center justify-center'>
					<h1 className='font-semibold text-2xl leading-tight my-7 capitalize'>Welcome Aboard</h1>
					<svg
						viewBox='0 0 512 512'
						version='1.1'
						xmlns='http://www.w3.org/2000/svg'
						className='w-9 h-9'
						fill='#000000'
					>
						<g id='SVGRepo_bgCarrier' strokeWidth='0'></g>
						<g id='SVGRepo_tracerCarrier' strokeLinecap='round' strokeLinejoin='round'></g>
						<g id='SVGRepo_iconCarrier'>
							<title>rocket</title>
							<g id='Page-1' stroke='none' strokeWidth='1' fill='none' fillRule='evenodd'>
								<g id='icon' fill='#000000' transform='translate(42.666667, 64.000000)'>
									<path
										d='M405.333333,1.42108547e-14 C396.316305,122.794806 364.316305,211.683695 309.333333,266.666667 C299.582265,276.417735 288.905446,285.33185 277.302879,293.409011 L277.302464,341.234872 L213.302464,405.234872 L174.248,336.891 L68.525,231.157 L7.10542736e-15,192 L64,128 L112.079613,128.000404 C120.083859,116.387258 128.94621,105.720457 138.666667,96 C193.649638,41.0170286 282.538527,9.01702859 405.333333,1.42108547e-14 Z M357.333333,47.9786667 L348.203556,49.3631108 C266.32942,62.2476147 206.763982,88.2424635 168.836556,126.169889 C146.004433,149.002012 128.637057,178.732412 116.876114,215.881246 L116.096,218.389333 L187.584,289.877333 L191.120585,288.76541 C224.531258,277.548675 251.975141,261.807487 273.818948,241.632769 L279.163444,236.496777 C317.09087,198.569351 343.085719,139.003914 355.970222,57.1297769 L357.333333,47.9786667 Z M75.9901363,269.368015 L30.7353023,314.622849 L0.565412939,284.452959 L45.8202469,239.198125 L75.9901363,269.368015 Z M121.24497,314.622849 L45.8202469,390.047572 L15.6503576,359.877683 L91.0750809,284.452959 L121.24497,314.622849 Z M136.329915,329.707793 L166.499804,359.877683 L121.24497,405.132517 L91.0750809,374.962627 L136.329915,329.707793 Z M245.333333,128 C263.006445,128 277.333333,142.326888 277.333333,160 C277.333333,177.673112 263.006445,192 245.333333,192 C227.660221,192 213.333333,177.673112 213.333333,160 C213.333333,142.326888 227.660221,128 245.333333,128 Z'
										id='Combined-Shape'
									></path>
								</g>
							</g>
						</g>
					</svg>
				</div>
				<div className='px-5 py-7 bg-white rounded-2xl w-full max-w-xl drop-shadow-lg'>
					<Form.Root className='flex flex-col gap-4' onSubmit={e => handleSubmit(e)}>
						<Form.Field className='flex flex-col gap-4 w-full items-center' name='profile-picture'>
							<Form.Label className='w-20 h-20 rounded-full overflow-hidden '>
								{profilePicture ? (
									<img
										src={URL.createObjectURL(profilePicture)}
										loading='lazy'
										className='object-cover w-full h-full'
										data-loading={false}
									/>
								) : (
									getDefaultAvatar('user')
								)}
							</Form.Label>
							{profilePicture ? (
								<button
									onClick={handleRemove}
									className='fade py-1 px-3 rounded-3xl bg-red-300/80 hover:bg-red-400/80 text-red-950 transition duration-200 ease-out'
								>
									Remove
								</button>
							) : (
								<label className='fade flex flex-col justify-center items-center bg-white drop-shadow-md px-5 py-2 rounded-full cursor-pointer transition-all duration-200 ease-out hover:brightness-[98%]'>
									<input
										type='file'
										id='profilePicture'
										accept='.jpeg, .jpg, .png, .gif'
										className='hidden'
										onChange={handleProfilePictureChange}
									/>
									<p className='text-sm'>Upload a photo</p>
									<span className='text-xs text-zinc-600'>(optional)</span>
								</label>
							)}
						</Form.Field>
						<Form.Field name='first-name'>
							<div className='flex items-baseline justify-between leading-loose'>
								<Form.Label>
									First Name <span className='text-red-400'>*</span>
								</Form.Label>
							</div>
							<Form.Control asChild>
								<input
									className={`box-border w-full p-2 rounded-lg border outline-none data-[invalid='true']:border-red-300 text-sm`}
									type='text'
									value={firstName}
									onChange={e => setFirstName(e.target.value)}
									required
								/>
							</Form.Control>

							<Form.Message className='text-xs text-red-500' match='valueMissing'>
								Please enter your first name
							</Form.Message>
							<Form.Message className='text-xs text-red-500' match='typeMismatch'>
								Please provide a valid first name
							</Form.Message>
						</Form.Field>
						<Form.Field name='last-name'>
							<div className='flex items-baseline justify-between leading-loose'>
								<Form.Label>
									Last Name <span className='text-red-400'>*</span>
								</Form.Label>
							</div>
							<Form.Control asChild>
								<input
									className={`box-border w-full p-2 rounded-lg border outline-none data-[invalid='true']:border-red-300 text-sm`}
									type='text'
									value={lastName}
									onChange={e => setLastName(e.target.value)}
									required
								/>
							</Form.Control>

							<Form.Message className='text-xs text-red-500' match='valueMissing'>
								Please enter your last name
							</Form.Message>
							<Form.Message className='text-xs text-red-500' match='typeMismatch'>
								Please provide a valid last name
							</Form.Message>
						</Form.Field>
						<Form.Field name='email'>
							<div className='flex items-baseline justify-between leading-loose'>
								<Form.Label>
									Email <span className='text-red-400'>*</span>
								</Form.Label>
							</div>
							<Form.Control asChild>
								<input
									className={`box-border w-full p-2 rounded-lg border outline-none data-[invalid='true']:border-red-300 text-sm ${
										emailAlreadyExists ? 'border-red-300' : ''
									}`}
									type='email'
									value={email}
									onChange={e => setEmail(e.target.value)}
									required
								/>
							</Form.Control>

							<Form.Message className='text-xs text-red-500' match='valueMissing'>
								Please enter your email
							</Form.Message>
							<Form.Message className='text-xs text-red-500' match='typeMismatch'>
								Please provide a valid email
							</Form.Message>
							{emailAlreadyExists && <div className='text-xs text-red-500'>Sorry, that email is already in use</div>}
						</Form.Field>
						<Form.Field name='password'>
							<div className='flex items-baseline justify-between leading-loose'>
								<Form.Label>
									Password <span className='text-red-400'>*</span>{' '}
									<span className='text-xs text-zinc-600'>(At least 6 characters long)</span>
								</Form.Label>
							</div>
							<Form.Control asChild>
								<input
									className={`box-border w-full p-2 rounded-lg border outline-none data-[invalid='true']:border-red-300 text-sm ${
										passwordIsInvalid ? 'border-red-300' : ''
									}`}
									type='password'
									required
									value={password}
									onChange={e => setPassword(e.target.value)}
								/>
							</Form.Control>
							<Form.Message className='text-xs text-red-500' match='valueMissing'>
								Please enter your password
							</Form.Message>
							<Form.Message className='text-xs text-red-500' match='typeMismatch'>
								Please provide a valid password
							</Form.Message>
							{passwordIsInvalid && <div className={`text-xs text-red-500`}>Password is too weak</div>}
						</Form.Field>
						{registerError && (
							<p className='text-sm text-red-500'>Sorry we were unable to create your account. Please try again</p>
						)}
						<p className='text-sm'>
							Already have an account?{' '}
							<Link
								className='text-zinc-500 underline underline-offset-1 hover:text-zinc-700 transition duration-100 ease-out'
								to={'/login'}
							>
								Login here
							</Link>
						</p>
						<Form.Submit asChild>
							<button className='w-full bg-accent hover:brightness-[96%] transition duration-200 ease-out text-white p-2 rounded-lg'>
								Register
							</button>
						</Form.Submit>
					</Form.Root>
				</div>
			</div>
		</MainLayout>
	)
}

export default Register
