import axios from 'axios'
import useSWR from 'swr'
import { API_URL } from '../api/constants'

const useImage = (userId: string): File | null => {
	if (parseInt(userId)) {
		const fetcher = (url: string) => axios.get(url).then(res => res.data)
		const { data } = useSWR(API_URL + '/users/' + userId + '/image', fetcher)
		return data
	}
	return null
}

export default useImage
