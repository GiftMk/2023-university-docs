import { Genre } from '../api/Genre'

const getGenre = (genreId: number, genres: Genre[]) => {
	return genres.find(g => g.genreId === genreId) || { genreId: -1, name: '' }
}

export default getGenre
