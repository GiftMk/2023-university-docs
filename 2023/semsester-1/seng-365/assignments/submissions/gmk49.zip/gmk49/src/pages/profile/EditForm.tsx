import * as Form from '@radix-ui/react-form'
import React from 'react'
import axios from 'axios'
import { API_URL } from '../../api/constants'
import { AuthContext } from '../../context/AuthContext'

const MIN_PASSWORD_SIZE = 6

interface Props {
	id: string
	password: string
	token: string
	setIsSuccessful: (isSuccessful: boolean) => void
}

const EditForm = ({
	id: authedUserId,
	password: authedUserPassword,
	token: authedUserToken,
	setIsSuccessful
}: Props) => {
	const [firstName, setFirstName] = React.useState('')
	const [lastName, setLastName] = React.useState('')
	const [email, setEmail] = React.useState('')
	const [password, setPassword] = React.useState('')

	const [editError, setEditError] = React.useState(false)
	const [emailAlreadyExists, setEmailAlreadyExists] = React.useState(false)
	const [passwordIsInvalid, setPasswordIsInvalid] = React.useState(false)
	const [passwordIsTheSame, setPasswordIsTheSame] = React.useState(false)

	const { updateAuth } = React.useContext(AuthContext)

	React.useEffect(() => {
		setEmailAlreadyExists(false)
	}, [email, password])

	React.useEffect(() => {
		if (password && password.length < MIN_PASSWORD_SIZE) {
			setPasswordIsInvalid(true)
		} else {
			setPasswordIsInvalid(false)
		}
		if (password && password === authedUserPassword) {
			setPasswordIsTheSame(true)
		} else {
			setPasswordIsTheSame(false)
		}
	}, [password])

	const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault()
		const data = {
			firstName: firstName,
			lastName: lastName,
			email: email,
			password: password,
			currentPassword: authedUserPassword
		}

		if (!emailAlreadyExists && !passwordIsInvalid && !passwordIsTheSame) {
			axios
				.patch(API_URL + '/users/' + authedUserId, data, {
					headers: {
						'X-Authorization': authedUserToken
					}
				})
				.then(
					() => {
						setIsSuccessful(true)
						updateAuth(authedUserId, authedUserToken, email, password)
					},
					error => {
						if (error.response) {
							if (error.response.status === 403) {
								if (authedUserPassword !== password) {
									setEmailAlreadyExists(true)
								}
							} else if (error.response.status === 400) {
								setPasswordIsInvalid(true)
							} else {
								setEditError(true)
							}
						}
						setIsSuccessful(false)
					}
				)
		}
	}

	return (
		<div className='w-full flex flex-col items-center justify-center'>
			<div className='flex gap-4 items-center justify-center'>
				<h1 className='font-semibold text-2xl leading-tight my-7 capitalize'>Edit Details</h1>
			</div>
			<div className='w-full'>
				<Form.Root className='flex flex-col gap-4' onSubmit={e => handleSubmit(e)}>
					<Form.Field name='first-name'>
						<div className='flex items-baseline justify-between leading-loose'>
							<Form.Label>
								First Name <span className='text-red-400'>*</span>
							</Form.Label>
						</div>
						<Form.Control asChild>
							<input
								className={`box-border w-full p-2 rounded-lg border outline-none data-[invalid='true']:border-red-300 text-sm`}
								type='text'
								value={firstName}
								onChange={e => setFirstName(e.target.value)}
								required
							/>
						</Form.Control>

						<Form.Message className='text-xs text-red-500' match='valueMissing'>
							Please enter your first name
						</Form.Message>
						<Form.Message className='text-xs text-red-500' match='typeMismatch'>
							Please provide a valid first name
						</Form.Message>
					</Form.Field>
					<Form.Field name='last-name'>
						<div className='flex items-baseline justify-between leading-loose'>
							<Form.Label>
								Last Name <span className='text-red-400'>*</span>
							</Form.Label>
						</div>
						<Form.Control asChild>
							<input
								className={`box-border w-full p-2 rounded-lg border outline-none data-[invalid='true']:border-red-300 text-sm`}
								type='text'
								value={lastName}
								onChange={e => setLastName(e.target.value)}
								required
							/>
						</Form.Control>

						<Form.Message className='text-xs text-red-500' match='valueMissing'>
							Please enter your last name
						</Form.Message>
						<Form.Message className='text-xs text-red-500' match='typeMismatch'>
							Please provide a valid last name
						</Form.Message>
					</Form.Field>
					<Form.Field name='email'>
						<div className='flex items-baseline justify-between leading-loose'>
							<Form.Label>
								Email <span className='text-red-400'>*</span>
							</Form.Label>
						</div>
						<Form.Control asChild>
							<input
								className={`box-border w-full p-2 rounded-lg border outline-none data-[invalid='true']:border-red-300 text-sm ${
									emailAlreadyExists ? 'border-red-300' : ''
								}`}
								type='email'
								value={email}
								onChange={e => setEmail(e.target.value)}
								required
							/>
						</Form.Control>

						<Form.Message className='text-xs text-red-500' match='valueMissing'>
							Please enter your email
						</Form.Message>
						<Form.Message className='text-xs text-red-500' match='typeMismatch'>
							Please provide a valid email
						</Form.Message>
						{emailAlreadyExists && <div className='text-xs text-red-500'>Sorry, that email is already in use</div>}
					</Form.Field>
					<Form.Field name='password'>
						<div className='flex items-baseline justify-between leading-loose'>
							<Form.Label>
								Password <span className='text-red-400'>*</span>{' '}
								<span className='text-xs text-zinc-600'>(At least 6 characters long)</span>
							</Form.Label>
						</div>
						<Form.Control asChild>
							<input
								className={`box-border w-full p-2 rounded-lg border outline-none data-[invalid='true']:border-red-300 text-sm ${
									passwordIsInvalid ? 'border-red-300' : ''
								}`}
								type='password'
								required
								value={password}
								onChange={e => setPassword(e.target.value)}
							/>
						</Form.Control>
						<Form.Message className='text-xs text-red-500' match='valueMissing'>
							Please enter your password
						</Form.Message>
						<Form.Message className='text-xs text-red-500' match='typeMismatch'>
							Please provide a valid password
						</Form.Message>
						{passwordIsInvalid && <div className={`text-xs text-red-500`}>Password is too weak</div>}
						{passwordIsTheSame && (
							<div className={`text-xs text-red-500`}>Your new password cannot be the same as your previous one</div>
						)}
					</Form.Field>
					{editError && (
						<p className='text-sm text-red-500'>Sorry we were unable to save your changes. Please try again</p>
					)}
					<Form.Submit asChild>
						<button className='w-full bg-accent hover:brightness-[96%] transition duration-200 ease-out text-white p-2 rounded-lg'>
							Save
						</button>
					</Form.Submit>
				</Form.Root>
			</div>
		</div>
	)
}

export default EditForm
