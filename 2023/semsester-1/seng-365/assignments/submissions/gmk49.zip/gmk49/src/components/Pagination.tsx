import { useContext } from 'react'
import { PaginationContext } from '../context/PaginationContext'

const Pagination = () => {
	const { currentPage, totalPages, updatePagination } = useContext(PaginationContext)
	const handleClick = (newCurrentPage: number) => {
		updatePagination(newCurrentPage, totalPages)
	}

	if (totalPages === 0) return null

	return (
		<div className='flex items-center justify-center w-full'>
			<div className='inline-flex gap-5'>
				<button
					className={`p-2 rounded-full transition duration-200 ease-out ${
						currentPage === 1 ? 'opacity-10' : 'hover:bg-zinc-200/50'
					}`}
					onClick={() => handleClick(1)}
					disabled={currentPage === 1}
				>
					<svg
						xmlns='http://www.w3.org/2000/svg'
						fill='none'
						viewBox='0 0 24 24'
						strokeWidth={1.75}
						stroke='currentColor'
						className='w-6 h-6'
					>
						<path strokeLinecap='round' strokeLinejoin='round' d='M18.75 19.5l-7.5-7.5 7.5-7.5m-6 15L5.25 12l7.5-7.5' />
					</svg>
				</button>
				<button
					className={`p-2 rounded-full transition duration-200 ease-out ${
						currentPage === 1 ? 'opacity-10' : 'hover:bg-zinc-200/50'
					}`}
					onClick={() => handleClick(currentPage - 1)}
					disabled={currentPage === 1}
				>
					<svg
						xmlns='http://www.w3.org/2000/svg'
						fill='none'
						viewBox='0 0 24 24'
						strokeWidth={1.75}
						stroke='currentColor'
						className='w-6 h-6'
					>
						<path strokeLinecap='round' strokeLinejoin='round' d='M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18' />
					</svg>
				</button>
			</div>

			<div className='inline-flex gap-2 text-2xl font-bold p-2 mx-auto xs:mx-9'>
				<span className='text-accent'>{currentPage}</span>
				<span>/</span>
				<span>{totalPages}</span>
			</div>

			<div className='inline-flex gap-5'>
				<button
					className={`p-2 rounded-full transition duration-200 ease-out ${
						currentPage === totalPages ? 'opacity-10' : 'hover:bg-zinc-200/50'
					}`}
					onClick={() => handleClick(currentPage + 1)}
					disabled={currentPage === totalPages}
				>
					<svg
						xmlns='http://www.w3.org/2000/svg'
						fill='none'
						viewBox='0 0 24 24'
						strokeWidth={1.75}
						stroke='currentColor'
						className='w-6 h-6'
					>
						<path strokeLinecap='round' strokeLinejoin='round' d='M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3' />
					</svg>
				</button>
				<button
					className={`p-2 rounded-full transition duration-200 ease-out ${
						currentPage === totalPages ? 'opacity-10' : 'hover:bg-zinc-200/50'
					}`}
					onClick={() => handleClick(totalPages)}
					disabled={currentPage === totalPages}
				>
					<svg
						xmlns='http://www.w3.org/2000/svg'
						fill='none'
						viewBox='0 0 24 24'
						strokeWidth={1.75}
						stroke='currentColor'
						className='w-6 h-6'
					>
						<path strokeLinecap='round' strokeLinejoin='round' d='M11.25 4.5l7.5 7.5-7.5 7.5m-6-15l7.5 7.5-7.5 7.5' />
					</svg>
				</button>
			</div>
		</div>
	)
}

export default Pagination
