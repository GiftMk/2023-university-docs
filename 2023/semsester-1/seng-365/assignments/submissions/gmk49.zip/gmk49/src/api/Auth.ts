export interface LoginResponse {
	userId: string
	token: string
}
