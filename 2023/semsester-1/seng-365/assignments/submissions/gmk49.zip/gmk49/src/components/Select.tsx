import { Listbox, Transition } from '@headlessui/react'

interface Props {
	trigger: JSX.Element
	options: Option[]
	selectedOptions: Option[]
	setSelectedOptions?: (options: Option[]) => void
	handleChange: (value: React.SetStateAction<any>) => void
	allowMultiSelect?: boolean
}

interface Option {
	label: string
	value: string
}

const Select = ({ trigger, options, selectedOptions, handleChange, allowMultiSelect = false }: Props) => {
	const isSelected = (genre: Option) => {
		return selectedOptions.some(g => g.value === genre.value)
	}

	return (
		<div className='w-full'>
			<Listbox value={selectedOptions} onChange={handleChange} multiple={allowMultiSelect}>
				<Listbox.Button
					className={`px-5 py-2.5 transition duration-200 ease-in-out rounded-3xl w-full ${
						allowMultiSelect && selectedOptions.length > 0
							? 'bg-green-300/80 hover:bg-green-400/80 text-green-950'
							: 'bg-white hover:bg-zinc-200/50'
					}`}
				>
					{trigger}
				</Listbox.Button>
				<Transition
					enter='transition duration-40 ease-in-out'
					enterFrom='transform scale-50 opacity-0'
					enterTo='transform scale-100 opacity-100'
					leave='transition duration-40 ease-in-out'
				>
					<Listbox.Options className='py-3 bg-white rounded-3xl w-full h-72 overflow-x-hidden overflow-y-auto mt-2.5'>
						{allowMultiSelect && selectedOptions.length > 0 && (
							<div className='flex items-center justify-center px-5 py-2.5 fade'>
								<button
									onClick={() => handleChange([])}
									className='py-1 px-3 rounded-3xl bg-red-300/80 hover:bg-red-400/80 text-red-950 transition duration-200 ease-out'
								>
									Clear all
								</button>
							</div>
						)}
						{options.map(option => (
							<Listbox.Option
								className='hover:cursor-pointer hover:bg-zinc-200/50 transition duration-200 ease-out px-5 py-2.5'
								key={option.value}
								value={option}
							>
								<div className='flex gap-2 items-center'>
									{isSelected(option) && (
										<svg
											xmlns='http://www.w3.org/2000/svg'
											fill='none'
											viewBox='0 0 24 24'
											strokeWidth={1.5}
											stroke='currentColor'
											className='w-5 h-5'
										>
											<path strokeLinecap='round' strokeLinejoin='round' d='M4.5 12.75l6 6 9-13.5' />
										</svg>
									)}
									{option.label}
								</div>
							</Listbox.Option>
						))}
					</Listbox.Options>
				</Transition>
			</Listbox>
		</div>
	)
}

export default Select
