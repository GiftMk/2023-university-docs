export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4941/api/v1'
