import { API_URL } from '../api/constants'
import { Review } from '../api/Review'
import * as Avatar from '@radix-ui/react-avatar'
import getDefaultAvatar from '../utils/avatar.utils'
import { getFormattedDate, truncate } from '../utils/strings.utils'
import * as Dialog from '@radix-ui/react-dialog'

interface Props {
	reviews: Review[]
}

interface ReviewDetailsProps {
	review: Review
}

const ReviewDetails = ({ review }: ReviewDetailsProps) => {
	return (
		<div className='flex flex-col gap-2'>
			<div className='flex items-center gap-3'>
				<svg
					version='1.0'
					id='Layer_1'
					xmlns='http://www.w3.org/2000/svg'
					viewBox='0 0 64 64'
					enableBackground='new 0 0 64 64'
					className='w-[1.125rem] h-[1.125rem]'
				>
					<g id='SVGRepo_bgCarrier' strokeWidth='0'></g>
					<g id='SVGRepo_tracerCarrier' strokeLinecap='round' strokeLinejoin='round'></g>
					<g id='SVGRepo_iconCarrier'>
						{' '}
						<path
							className='fill-amber-400'
							d='M62.799,23.737c-0.47-1.399-1.681-2.419-3.139-2.642l-16.969-2.593L35.069,2.265 C34.419,0.881,33.03,0,31.504,0c-1.527,0-2.915,0.881-3.565,2.265l-7.623,16.238L3.347,21.096c-1.458,0.223-2.669,1.242-3.138,2.642 c-0.469,1.4-0.115,2.942,0.916,4l12.392,12.707l-2.935,17.977c-0.242,1.488,0.389,2.984,1.62,3.854 c1.23,0.87,2.854,0.958,4.177,0.228l15.126-8.365l15.126,8.365c0.597,0.33,1.254,0.492,1.908,0.492c0.796,0,1.592-0.242,2.269-0.72 c1.231-0.869,1.861-2.365,1.619-3.854l-2.935-17.977l12.393-12.707C62.914,26.68,63.268,25.138,62.799,23.737z'
						></path>{' '}
					</g>
				</svg>
				<p className='font-bold text-lg'>{review.rating}</p>
			</div>

			<div className='flex flex-wrap max-w-full items-center gap-3.5'>
				<Avatar.Root className='w-8 h-8 flex items-center justify-center overflow-hidden rounded-full'>
					<Avatar.Image
						src={`${API_URL}/users/${review.reviewerId}/image`}
						alt='director-profile-picture'
						className='aspect-square object-cover'
						loading='lazy'
					/>
					<Avatar.Fallback className='AvatarFallback' delayMs={100}>
						{getDefaultAvatar(`${review.reviewerFirstName} ${review.reviewerLastName}`)}
					</Avatar.Fallback>
				</Avatar.Root>
				<p className='capitalize truncate'>
					<span>{review.reviewerFirstName}</span>
					&nbsp;
					<span>{review.reviewerLastName}</span>
				</p>
			</div>
			<p className='text-xs'>{getFormattedDate(review.timestamp)}</p>
		</div>
	)
}

const Reviews = ({ reviews }: Props) => {
	if (reviews.length === 0) return null
	return (
		<div className='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5'>
			{reviews.map((review, id) => (
				<Dialog.Root key={id}>
					<Dialog.Trigger className='flex flex-col gap-7 p-5 bg-white rounded-3xl hover:drop-shadow-lg hover:-translate-y-1 transition ease-in-out duration-200 overflow-hidden'>
						<ReviewDetails review={review} />
						<div className='text-sm text-left'>
							<p>{truncate(review.review, 100, false)}</p>
						</div>
					</Dialog.Trigger>
					<Dialog.Portal>
						<Dialog.Overlay className='bg-black/70 fixed inset-0 z-10 fade' />
						<Dialog.Content className='fixed top-[50%] left-[50%] w-[80vw] sm:w-[60vw] md:w-[50vw] lg:w-[40vw] xl:w-[30vw] translate-x-[-50%] translate-y-[-50%] rounded-3xl bg-white p-7 z-50 shadow-lg'>
							<Dialog.Close className='absolute rounded-3xl top-2.5 right-2.5 p-2 hover:bg-zinc-200/50 transition duration-200 ease-out'>
								<svg
									xmlns='http://www.w3.org/2000/svg'
									fill='none'
									viewBox='0 0 24 24'
									strokeWidth={1.5}
									stroke='currentColor'
									className='w-6 h-6'
								>
									<path strokeLinecap='round' strokeLinejoin='round' d='M6 18L18 6M6 6l12 12' />
								</svg>
							</Dialog.Close>
							<div className='flex flex-col gap-7 overflow-auto'>
								<ReviewDetails review={review} />
								<p>{review.review}</p>
							</div>
						</Dialog.Content>
					</Dialog.Portal>
				</Dialog.Root>
			))}
		</div>
	)
}

export default Reviews
