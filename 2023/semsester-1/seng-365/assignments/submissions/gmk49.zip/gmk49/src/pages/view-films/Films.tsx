import useSWR from 'swr'
import axios from 'axios'
import FilmCard from '../../components/FilmCard'
import useGenres from '../../hooks/useGenres'
import { Film } from '../../api/Film'
import { Genre } from '../../api/Genre'
import { Link, useSearchParams } from 'react-router-dom'
import { API_URL } from '../../api/constants'
import { useContext } from 'react'
import { PaginationContext } from '../../context/PaginationContext'
import React from 'react'
import getGenre from '../../utils/genres.utils'
import { AuthContext } from '../../context/AuthContext'

const PAGE_SIZE = 9

const Films = () => {
	const { authedUserId } = React.useContext(AuthContext)
	const { currentPage, totalPages, updatePagination } = useContext(PaginationContext)
	const startIndex = (currentPage - 1) * PAGE_SIZE

	const [searchParams] = useSearchParams()
	const searchParamsObject = Object.fromEntries(searchParams.entries())
	if (searchParamsObject.q === '') delete searchParamsObject.q
	searchParamsObject.startIndex = startIndex.toString()
	searchParamsObject.count = PAGE_SIZE.toString()

	const fetcher = (url: string, params?: object) => axios.get(url, { params: params }).then(res => res.data)

	const { data: filmsData } = useSWR(
		[API_URL + '/films', searchParamsObject],
		([url, params]) => fetcher(url, params),
		{
			keepPreviousData: true
		}
	)
	const { data: genresData } = useGenres()

	React.useEffect(() => {
		updatePagination(1, totalPages)
	}, [searchParams])

	React.useEffect(() => {
		window.scrollTo({ top: 0 })
	}, [currentPage])

	React.useEffect(() => {
		if (filmsData) {
			const newTotalPages = Math.ceil(filmsData.count / PAGE_SIZE)
			updatePagination(currentPage, newTotalPages)
		}
	}, [filmsData])

	if (filmsData && genresData) {
		const films: Film[] = filmsData.films
		const genres: Genre[] = genresData

		if (totalPages > 0) {
			return (
				<ul className='w-full h-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 fade'>
					{films.map((film, id) => (
						<li key={id}>
							<Link
								className='hover:brightness-[99%] hover:drop-shadow-lg transition ease-in-out duration-150'
								to={`/film/${film.filmId}`}
							>
								<FilmCard film={film} genre={getGenre(film.genreId, genres)} />
							</Link>
						</li>
					))}
				</ul>
			)
		}
		return (
			<div className='flex items-center justify-center w-full h-40 font-semibold fade'>
				No films match your criteria
			</div>
		)
	}

	return null
}

export default Films
