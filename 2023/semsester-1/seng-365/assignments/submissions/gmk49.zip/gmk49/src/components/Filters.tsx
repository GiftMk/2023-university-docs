import { useSearchParams } from 'react-router-dom'
import useGenres from '../hooks/useGenres'
import { Genre } from '../api/Genre'
import { useState } from 'react'
import React from 'react'
import Select from './Select'
import { ageRatings } from './AgeRating'

interface Option {
	label: string
	value: string
}

const sortOptions: Option[] = [
	{ label: 'Oldest → Newest', value: 'RELEASED_ASC' },
	{ label: 'Newest → Oldest', value: 'RELEASED_DESC' },
	{ label: 'Title A → Z', value: 'ALPHABETICAL_ASC' },
	{ label: 'Title Z → A', value: 'ALPHABETICAL_DESC' },
	{ label: 'Rating High → Low', value: 'RATING_DESC' },
	{ label: 'Rating Low → High', value: 'RATING_ASC' }
]

const SelectSort = () => {
	const [selectedOption, setSelectedOption] = useState(sortOptions[0])
	const [searchParams, setSearchParams] = useSearchParams()

	const handleChange = (value: React.SetStateAction<Option>) => {
		const option = value as Option
		setSelectedOption(option)
		searchParams.set('sortBy', option.value)
		setSearchParams(searchParams)
	}

	return (
		<Select
			trigger={<p>{selectedOption.label}</p>}
			options={sortOptions}
			selectedOptions={[selectedOption]}
			handleChange={handleChange}
		/>
	)
}

const getUniqueOptions = (options: Option[]): Option[] => {
	const uniqueOptions: Option[] = []
	for (var option of options) {
		if (!uniqueOptions.some(o => o.value === option.value)) {
			uniqueOptions.push(option)
		}
	}
	return uniqueOptions
}

const SelectGenres = () => {
	const { data } = useGenres()
	const [options, setOptions] = useState<Option[]>([])
	const [selectedOptions, setSelectedOptions] = useState<Option[]>([])
	const [searchParams, setSearchParams] = useSearchParams()

	React.useEffect(() => {
		if (data) {
			const genreIds = searchParams.getAll('genreIds')
			const genres = data as Genre[]
			const options = genres.map(genre => ({ label: genre.name, value: genre.genreId.toString() }))
			const selectedOptions = options.filter(option => genreIds.includes(option.value))
			setOptions(options)
			setSelectedOptions(selectedOptions)
		}
	}, [data])

	const handleChange = (value: React.SetStateAction<Option[]>) => {
		const options = value as Option[]
		const uniqueOptions = getUniqueOptions(options)
		setSelectedOptions(uniqueOptions)
		searchParams.delete('genreIds')
		uniqueOptions.forEach(option => searchParams.append('genreIds', option.value))
		setSearchParams(searchParams)
	}

	return (
		<Select
			trigger={<p>Genre</p>}
			options={options}
			selectedOptions={selectedOptions}
			setSelectedOptions={setSelectedOptions}
			handleChange={handleChange}
			allowMultiSelect={true}
		/>
	)
}

const SelectAgeRating = () => {
	const [options, setOptions] = React.useState<Option[]>([])
	const [selectedOptions, setSelectedOptions] = useState<Option[]>([])
	const [searchParams, setSearchParams] = useSearchParams()

	React.useEffect(() => {
		const options = ageRatings.map(ageRating => ({ label: ageRating, value: ageRating }))
		const existingAgeRatings = searchParams.getAll('ageRatings')
		const selectedOptions = options.filter(option => existingAgeRatings.includes(option.value))
		setOptions(options)
		setSelectedOptions(selectedOptions)
	}, [])

	const handleChange = (value: React.SetStateAction<Option[]>) => {
		const options = value as Option[]
		const uniqueOptions = getUniqueOptions(options)
		setSelectedOptions(uniqueOptions)
		searchParams.delete('ageRatings')
		uniqueOptions.forEach(option => searchParams.append('ageRatings', option.value))
		setSearchParams(searchParams)
	}

	return (
		<Select
			trigger={<p>Age Rating</p>}
			options={options}
			selectedOptions={selectedOptions}
			setSelectedOptions={setSelectedOptions}
			handleChange={handleChange}
			allowMultiSelect={true}
		/>
	)
}

const Filters = () => {
	return (
		<div className='grid grid-cols-1 sm:grid-cols-3 gap-5'>
			<SelectSort />
			<SelectGenres />
			<SelectAgeRating />
		</div>
	)
}

export default Filters
