import './App.css'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import ViewFilms from './pages/ViewFilms'
import ViewFilm from './pages/view-films/ViewFilm'
import Login from './pages/Login'
import { AuthProvider } from './context/AuthContext'
import Register from './pages/Register'
import Profile from './pages/profile/Profile'

const App = () => {
	return (
		<AuthProvider>
			<BrowserRouter>
				<Routes>
					<Route path='/' element={<Navigate to={'/films'} />} />
					<Route path='/films' element={<ViewFilms />} />
					<Route path='/film/:id' element={<ViewFilm />} />
					<Route path='/login' element={<Login />} />
					<Route path='/register' element={<Register />} />
					<Route path='/profile' element={<Profile />} />
				</Routes>
			</BrowserRouter>
		</AuthProvider>
	)
}

export default App
