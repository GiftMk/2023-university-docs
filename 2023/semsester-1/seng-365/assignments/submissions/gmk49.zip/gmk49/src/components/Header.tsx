import * as NavigationMenu from '@radix-ui/react-navigation-menu'
import { NavLink } from 'react-router-dom'
import React from 'react'
import { AuthContext } from '../context/AuthContext'

interface MenuLink {
	href: string
	name: string
}

const links: MenuLink[] = [{ href: '/films', name: 'Films' }]

interface MenuLinkProps {
	styles?: string[]
}

const MenuLinks = ({ styles }: MenuLinkProps) => {
	return (
		<>
			{links.map((link, i) => (
				<NavLink
					key={i}
					className={({ isActive }) => `${isActive ? 'font-semibold' : ''} ${styles?.join(' ')}`}
					to={link.href}
				>
					{link.name}
				</NavLink>
			))}
		</>
	)
}

const Header = () => {
	const { authedUserId } = React.useContext(AuthContext)
	return (
		<NavigationMenu.Root className='fixed top-0 flex items-center bg-white/90 backdrop-blur-3xl drop-shadow-[6px_-3px_6px_rgba(0,0,0,0.25)] z-[1] transition ease-out delay-75 duration-40'>
			<NavigationMenu.List className='h-nav-height w-screen flex items-center px-8'>
				<NavigationMenu.Item className='flex flex-1'>
					<MenuLinks
						styles={['p-2', 'rounded-3xl', 'hover:bg-zinc-200/50', 'transition', 'duration-200', 'ease-out']}
					/>
				</NavigationMenu.Item>
				<NavigationMenu.Item className='p-2'>
					<NavLink to='/' className='flex gap-2 items-center justify-center'>
						<img src='/logo-icon.svg' alt='logo-icon' />
						<p className='font-black text-lg'>SWISH</p>
					</NavLink>
				</NavigationMenu.Item>
				<NavigationMenu.Item className='flex flex-1 justify-end'>
					{authedUserId ? (
						<NavLink
							className='flex items-center gap-3 hover:opacity-70 transition ease-in-out duration-200'
							to='/profile'
						>
							<div className='w-9 h-9 flex items-center justify-center overflow-hidden rounded-full'>
								<svg
									xmlns='http://www.w3.org/2000/svg'
									fill='none'
									viewBox='0 0 24 24'
									strokeWidth={1}
									stroke='currentColor'
									className='w-full h-full'
								>
									<path
										strokeLinecap='round'
										strokeLinejoin='round'
										d='M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z'
									/>
								</svg>
							</div>
						</NavLink>
					) : (
						<NavLink to='/login' className='p-2 rounded-3xl hover:bg-zinc-200/50 transition duration-200 ease-out'>
							Log in
						</NavLink>
					)}
				</NavigationMenu.Item>
			</NavigationMenu.List>
		</NavigationMenu.Root>
	)
}

export default Header
