import React from 'react'
import { useSearchParams } from 'react-router-dom'
import { useDebounce } from 'use-debounce'

const SearchBar = () => {
	const [query, setQuery] = React.useState('')
	const [searchParams, setSearchParams] = useSearchParams()
	const [debouncedQuery] = useDebounce(query, 300)

	React.useEffect(() => {
		searchParams.set('q', debouncedQuery)
		setSearchParams(searchParams)
	}, [debouncedQuery])

	const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault()
		searchParams.set('q', query)
		setSearchParams(searchParams)
	}

	return (
		<form
			className='flex w-full bg-white rounded-3xl px-2.5 drop-shadow-[5px_5px_15px_rgba(0,0,0,0.03)] overflow-hidden'
			onSubmit={e => handleSubmit(e)}
		>
			<button className='p-2.5' type='submit'>
				<svg
					xmlns='http://www.w3.org/2000/svg'
					fill='none'
					viewBox='0 0 24 24'
					strokeWidth={1.75}
					stroke='currentColor'
					className='w-5 h-5'
				>
					<path
						strokeLinecap='round'
						strokeLinejoin='round'
						d='M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z'
					/>
				</svg>
			</button>
			<input
				placeholder='Search...'
				className='w-full flex py-2.5 mr-1 focus:outline-none'
				value={query}
				onChange={e => setQuery(e.target.value)}
			/>
		</form>
	)
}

export default SearchBar
