export interface Review {
	reviewerId: number
	rating: number
	review: string
	reviewerFirstName: string
	reviewerLastName: string
	timestamp: string
}
