import SearchBar from '../components/SearchBar'
import Films from './view-films/Films'
import Pagination from '../components/Pagination'
import { PaginationProvider } from '../context/PaginationContext'
import MainLayout from '../layouts/MainLayout'
import Filters from '../components/Filters'

const ViewFilms = () => {
	return (
		<MainLayout>
			<h1 className='text-2xl font-medium my-4 text-black/[100%]'>Browse</h1>
			<SearchBar />
			<Filters />
			<PaginationProvider>
				<Films />
				<Pagination />
			</PaginationProvider>
		</MainLayout>
	)
}

export default ViewFilms
