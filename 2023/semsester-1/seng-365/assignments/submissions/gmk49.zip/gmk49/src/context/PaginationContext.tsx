import React from 'react'

interface PaginationContextType {
	currentPage: number
	totalPages: number
	updatePagination: (newCurrentPage: number, newTotalPages: number) => void
}

export const PaginationContext = React.createContext<PaginationContextType>({
	currentPage: 1,
	totalPages: 0,
	updatePagination: () => {}
})

interface PaginationProviderProps {
	children: React.ReactNode
}

export const PaginationProvider = ({ children }: PaginationProviderProps) => {
	const [currentPage, setCurrentPage] = React.useState(1)
	const [totalPages, setTotalPages] = React.useState(0)

	const canUpdatePagination = (newCurrentPage: number, newTotalPages: number) => {
		if (newTotalPages < 0) return false
		if (newCurrentPage < 1) return false
		if (newTotalPages !== 0 && newTotalPages < newCurrentPage) return false
		return true
	}

	const updatePagination = (newCurrentPage: number, newTotalPages: number) => {
		if (canUpdatePagination(newCurrentPage, newTotalPages)) {
			if (newCurrentPage !== currentPage) setCurrentPage(newCurrentPage)
			if (newTotalPages !== totalPages) setTotalPages(newTotalPages)
		}
	}

	return (
		<PaginationContext.Provider value={{ currentPage, totalPages, updatePagination }}>
			{children}
		</PaginationContext.Provider>
	)
}
