import { FilmDetails } from '../api/Film'
import * as Avatar from '@radix-ui/react-avatar'
import { AgeRating, getColor } from './AgeRating'
import { Genre } from '../api/Genre'
import { API_URL } from '../api/constants'
import React from 'react'
import getDefaultAvatar from '../utils/avatar.utils'
import { getFormattedDate } from '../utils/strings.utils'

interface Props {
	film: FilmDetails
	genre: Genre
}

const NUM_FALLBACK_IMAGES = 4

const FilmDetailsCard = ({ film, genre }: Props) => {
	const ageRatingColor = getColor(film.ageRating as AgeRating)

	const handleOnError = (event: React.SyntheticEvent<HTMLImageElement, Event>) => {
		const fallbackIndex = Math.floor(Math.random() * NUM_FALLBACK_IMAGES) + 1
		const fallbackImage = `/film-fallback-${fallbackIndex}.svg`
		event.currentTarget.src = fallbackImage
	}

	return (
		<div className='flex flex-col items-start overflow-x-hidden justify-center bg-white rounded-3xl p-5 gap-5'>
			<div className='relative w-full'>
				<div className='rounded-3xl overflow-hidden w-full aspect-[1.85/1]'>
					<img
						src={`${API_URL}/films/${film.filmId}/image`}
						onError={handleOnError}
						alt='film image'
						className={`object-cover object-center w-full aspect-[1.85/1]`}
						loading='lazy'
					/>
				</div>
			</div>
			<p className='font-semibold text-2xl capitalize'>{film.title}</p>
			<p>{film.description}</p>
			<p className='font-medium'>Director</p>
			<div className='flex flex-wrap max-w-full items-center gap-5'>
				<Avatar.Root className='w-10 h-10 flex items-center justify-center overflow-hidden rounded-full'>
					<Avatar.Image
						src={`${API_URL}/users/${film.directorId}/image`}
						alt='director-profile-picture'
						className='aspect-square object-cover'
						loading='lazy'
					/>
					<Avatar.Fallback className='AvatarFallback' delayMs={100}>
						{getDefaultAvatar(`${film.directorFirstName} ${film.directorLastName}`)}
					</Avatar.Fallback>
				</Avatar.Root>
				<p className='capitalize'>
					<span>{film.directorFirstName}</span>
					&nbsp;
					<span>{film.directorLastName}</span>
				</p>
			</div>
			<p>
				<span className='font-medium'>Released on</span>
				&nbsp;
				{getFormattedDate(film.releaseDate)}
			</p>
			<div className='flex w-full items-center gap-5'>
				<span className={`px-2 py-1 ${ageRatingColor} rounded-full text-white text-sm`}>{film.ageRating}</span>
				<span className='text-sm px-2 py-1 rounded-full bg-[#f58d56] text-white'>{genre.name}</span>
			</div>
		</div>
	)
}

export default FilmDetailsCard
