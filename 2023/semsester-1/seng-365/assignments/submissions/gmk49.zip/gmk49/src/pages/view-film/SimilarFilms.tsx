import axios from 'axios'
import useSWR from 'swr'
import { API_URL } from '../../api/constants'
import { Film } from '../../api/Film'
import FilmCard from '../../components/FilmCard'
import { Genre } from '../../api/Genre'
import { Link } from 'react-router-dom'
import React from 'react'

interface Props {
	filmId: number
	genreId: number
	directorId: number
	genre: Genre
}

const DEFAULT_NUM_FILMS_TO_SHOW = 3

const getSimilarFilms = (sameGenreFilms: Film[], sameDirectorFilms: Film[], filmId: number): Film[] => {
	const films = sameGenreFilms.concat(sameDirectorFilms).filter(film => film.filmId !== filmId)
	const uniqueFilms: Film[] = []
	for (var film of films) {
		if (!uniqueFilms.some(f => f.filmId === film.filmId)) {
			uniqueFilms.push(film)
		}
	}
	uniqueFilms.sort((a, b) => b.rating - a.rating)
	return uniqueFilms
}

const SimilarFilms = ({ filmId, genreId, directorId, genre }: Props) => {
	const fetcher = (url: string, params?: object) => axios.get(url, { params: params }).then(res => res.data)
	const { data: sameGenreData } = useSWR([API_URL + '/films', { genreIds: genreId }], ([url, params]) =>
		fetcher(url, params)
	)
	const { data: sameDirectorData } = useSWR([API_URL + '/films', { directorId: directorId }], ([url, params]) =>
		fetcher(url, params)
	)

	const [numFilmsToShow, setNumFilmsToShow] = React.useState<number | undefined>(DEFAULT_NUM_FILMS_TO_SHOW)
	const handleExpand = () => {
		if (numFilmsToShow === DEFAULT_NUM_FILMS_TO_SHOW) {
			setNumFilmsToShow(undefined)
		}
	}
	const handleClose = () => {
		setNumFilmsToShow(DEFAULT_NUM_FILMS_TO_SHOW)
	}

	if (sameGenreData && sameDirectorData) {
		const films = getSimilarFilms(sameGenreData.films, sameDirectorData.films, filmId)
		const filmsToShow = films.slice(0, numFilmsToShow)
		if (filmsToShow.length > 0) {
			return (
				<>
					<h1 className='text-xl font-medium w-full p-5 rounded-3xl bg-white'>More films like this</h1>
					<div className='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5'>
						{filmsToShow.map((film, id) => (
							<Link
								className='hover:brightness-[99%] hover:drop-shadow-lg transition ease-in-out duration-150'
								to={`/film/${film.filmId}`}
							>
								<FilmCard key={id} film={film} genre={genre} />
							</Link>
						))}
					</div>
					{films.length > DEFAULT_NUM_FILMS_TO_SHOW && (
						<div className='w-full flex items-center justify-center'>
							{numFilmsToShow === DEFAULT_NUM_FILMS_TO_SHOW ? (
								<button
									className='p-1.5 bg-accent rounded-full hover:brightness-95 transition duration-200 ease-out fade'
									onClick={handleExpand}
								>
									<svg
										xmlns='http://www.w3.org/2000/svg'
										viewBox='0 0 24 24'
										fill='currentColor'
										className='w-6 h-6 text-white'
									>
										<path
											fillRule='evenodd'
											d='M20.03 4.72a.75.75 0 010 1.06l-7.5 7.5a.75.75 0 01-1.06 0l-7.5-7.5a.75.75 0 011.06-1.06L12 11.69l6.97-6.97a.75.75 0 011.06 0zm0 6a.75.75 0 010 1.06l-7.5 7.5a.75.75 0 01-1.06 0l-7.5-7.5a.75.75 0 111.06-1.06L12 17.69l6.97-6.97a.75.75 0 011.06 0z'
											clipRule='evenodd'
										/>
									</svg>
								</button>
							) : (
								<button
									className='p-1.5 bg-accent rounded-full hover:brightness-95 transition duration-200 ease-out fade'
									onClick={handleClose}
								>
									<svg
										xmlns='http://www.w3.org/2000/svg'
										viewBox='0 0 24 24'
										fill='currentColor'
										className='w-6 h-6 text-white'
									>
										<path
											fillRule='evenodd'
											d='M11.47 4.72a.75.75 0 011.06 0l7.5 7.5a.75.75 0 11-1.06 1.06L12 6.31l-6.97 6.97a.75.75 0 01-1.06-1.06l7.5-7.5zm.53 7.59l-6.97 6.97a.75.75 0 01-1.06-1.06l7.5-7.5a.75.75 0 011.06 0l7.5 7.5a.75.75 0 11-1.06 1.06L12 12.31z'
											clipRule='evenodd'
										/>
									</svg>
								</button>
							)}
						</div>
					)}
				</>
			)
		}
	}
	return null
}

export default SimilarFilms
