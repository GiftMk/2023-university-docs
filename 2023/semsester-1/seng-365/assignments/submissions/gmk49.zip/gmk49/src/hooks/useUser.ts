import axios from 'axios'
import useSWR from 'swr'
import { API_URL } from '../api/constants'
import { User } from '../api/User'

const useUser = (userId: string): User | null => {
	if (parseInt(userId)) {
		const fetcher = (url: string) => axios.get(url).then(res => res.data)
		const { data } = useSWR(API_URL + '/users/' + userId, fetcher)
		return data
	}
	return null
}

export default useUser
