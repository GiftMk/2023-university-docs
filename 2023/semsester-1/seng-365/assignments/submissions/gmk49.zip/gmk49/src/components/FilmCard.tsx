import { Film } from '../api/Film'
import * as Avatar from '@radix-ui/react-avatar'
import { AgeRating, getColor } from './AgeRating'
import { Genre } from '../api/Genre'
import { API_URL } from '../api/constants'
import React from 'react'
import getDefaultAvatar from '../utils/avatar.utils'
import { getFormattedDate } from '../utils/strings.utils'

interface Props {
	film: Film
	genre: Genre
}

const NUM_FALLBACK_IMAGES = 4

const FilmCard = ({ film, genre }: Props) => {
	const ageRatingColor = getColor(film.ageRating as AgeRating)

	const handleOnError = (event: React.SyntheticEvent<HTMLImageElement, Event>) => {
		const fallbackIndex = Math.floor(Math.random() * NUM_FALLBACK_IMAGES) + 1
		const fallbackImage = `/film-fallback-${fallbackIndex}.svg`
		event.currentTarget.src = fallbackImage
	}

	return (
		<div className='flex flex-col items-start overflow-x-hidden justify-center bg-white rounded-3xl p-5 gap-5'>
			<div className='relative w-full'>
				<div className='rounded-3xl overflow-hidden w-full aspect-[1.85/1]'>
					<img
						src={`${API_URL}/films/${film.filmId}/image`}
						onError={handleOnError}
						alt='film image'
						className={`object-cover object-center w-full aspect-[1.85/1]`}
						loading='lazy'
					/>
				</div>
				<div className='flex items-center gap-2 absolute top-0 left-0 ml-2 mt-3 px-2 py-1.5 rounded-full bg-stone-950/60 shadow-md backdrop-blur-lg text-white text-sm'>
					<svg
						version='1.0'
						id='Layer_1'
						xmlns='http://www.w3.org/2000/svg'
						viewBox='0 0 64 64'
						enableBackground='new 0 0 64 64'
						className='w-3.5 h-3.5'
					>
						<g id='SVGRepo_bgCarrier' strokeWidth='0'></g>
						<g id='SVGRepo_tracerCarrier' strokeLinecap='round' strokeLinejoin='round'></g>
						<g id='SVGRepo_iconCarrier'>
							{' '}
							<path
								className='fill-amber-400'
								d='M62.799,23.737c-0.47-1.399-1.681-2.419-3.139-2.642l-16.969-2.593L35.069,2.265 C34.419,0.881,33.03,0,31.504,0c-1.527,0-2.915,0.881-3.565,2.265l-7.623,16.238L3.347,21.096c-1.458,0.223-2.669,1.242-3.138,2.642 c-0.469,1.4-0.115,2.942,0.916,4l12.392,12.707l-2.935,17.977c-0.242,1.488,0.389,2.984,1.62,3.854 c1.23,0.87,2.854,0.958,4.177,0.228l15.126-8.365l15.126,8.365c0.597,0.33,1.254,0.492,1.908,0.492c0.796,0,1.592-0.242,2.269-0.72 c1.231-0.869,1.861-2.365,1.619-3.854l-2.935-17.977l12.393-12.707C62.914,26.68,63.268,25.138,62.799,23.737z'
							></path>{' '}
						</g>
					</svg>
					<p className='font-bold'>{film.rating ? film.rating : 'None'}</p>
				</div>
			</div>
			<p className='font-semibold capitalize'>{film.title}</p>
			<div className='flex flex-wrap max-w-full items-center gap-5'>
				<Avatar.Root className='w-10 h-10 flex items-center justify-center overflow-hidden rounded-full'>
					<Avatar.Image
						src={`${API_URL}/users/${film.directorId}/image`}
						alt='director-profile-picture'
						className='aspect-square object-cover'
						loading='lazy'
					/>
					<Avatar.Fallback className='AvatarFallback' delayMs={100}>
						{getDefaultAvatar(`${film.directorFirstName} ${film.directorLastName}`)}
					</Avatar.Fallback>
				</Avatar.Root>
				<p className='capitalize'>
					<span>{film.directorFirstName}</span>
					&nbsp;
					<span>{film.directorLastName}</span>
				</p>
			</div>
			<p className='text-sm'>{getFormattedDate(film.releaseDate, false)}</p>
			<div className='flex w-full items-center justify-between'>
				<span className={`px-2 py-1 ${ageRatingColor} rounded-full text-white text-sm`}>{film.ageRating}</span>
				<span className='text-sm px-2 py-1 rounded-full bg-[#f58d56] text-white'>{genre.name}</span>
			</div>
		</div>
	)
}

export default FilmCard
