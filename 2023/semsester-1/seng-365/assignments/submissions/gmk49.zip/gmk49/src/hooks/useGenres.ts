import useSWR, { SWRResponse } from 'swr'
import axios from 'axios'
import { API_URL } from '../api/constants'

const useGenres = (): SWRResponse => {
	const fetcher = (url: string, params: object) => axios.get(url, { params: params }).then(res => res.data)
	return useSWR(API_URL + '/films/genres', fetcher)
}

export default useGenres
