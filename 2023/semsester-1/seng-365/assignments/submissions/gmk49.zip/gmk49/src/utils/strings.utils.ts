import moment from 'moment'

const getFormattedDate = (timestamp: string, includeTime = true) => {
	if (includeTime) {
		return moment(timestamp).format('MMMM Do, YYYY, h:mm a')
	}
	return moment(timestamp).format('MMMM Do, YYYY')
}

const truncate = (text: string, length: number, wholeWordsOnly = true): string => {
	if (text && text.length > length) {
		if (wholeWordsOnly) {
			while (text.charAt(length).trim() !== '') length--
		}
		return text.slice(0, length) + '...'
	}
	return text
}

export { getFormattedDate, truncate }
