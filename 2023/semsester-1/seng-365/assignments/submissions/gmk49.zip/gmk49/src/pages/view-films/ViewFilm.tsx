import axios from 'axios'
import FilmDetailsCard from '../../components/FilmDetailsCard'
import MainLayout from '../../layouts/MainLayout'
import { useParams } from 'react-router-dom'
import useSWR from 'swr'
import { API_URL } from '../../api/constants'
import { FilmDetails } from '../../api/Film'
import getGenre from '../../utils/genres.utils'
import useGenres from '../../hooks/useGenres'
import { Genre } from '../../api/Genre'
import Reviews from '../../components/Reviews'
import { Review } from '../../api/Review'
import React from 'react'
import SimilarFilms from '../view-film/SimilarFilms'

const DEFAULT_NUM_REVIEWS_TO_SHOW = 3

const ViewFilm = () => {
	const params = useParams()
	const filmId = parseInt(params.id || '', 10)
	const [numReviewsToShow, setNumReviewsToShow] = React.useState<number | undefined>(DEFAULT_NUM_REVIEWS_TO_SHOW)

	const handleExpand = () => {
		if (numReviewsToShow === DEFAULT_NUM_REVIEWS_TO_SHOW) {
			setNumReviewsToShow(undefined)
		}
	}

	const handleClose = () => {
		setNumReviewsToShow(DEFAULT_NUM_REVIEWS_TO_SHOW)
	}

	const fetcher = (url: string, params?: object) => axios.get(url, { params: params }).then(res => res.data)
	const { data: filmData } = useSWR(API_URL + '/films/' + filmId, fetcher)
	const { data: genresData } = useGenres()
	const { data: reviewsData } = useSWR(API_URL + '/films/' + filmId + '/reviews', fetcher)

	if (filmData && genresData && reviewsData) {
		const filmDetails: FilmDetails = filmData
		const genres: Genre[] = genresData
		const genre = getGenre(filmDetails.genreId, genres)
		const reviews: Review[] = reviewsData
		const reviewsToShow = reviews.slice(0, numReviewsToShow)

		return (
			<MainLayout>
				<FilmDetailsCard film={filmDetails} genre={genre} />
				<div className='p-5 rounded-3xl bg-white flex flex-col gap-3'>
					{reviews.length > 0 ? (
						<>
							<h1 className='text-xl font-medium'>Rated {filmDetails.rating} / 10</h1>
							<p className='text-sm'>From {reviews.length} reviews</p>
						</>
					) : (
						<h1 className='text-xl font-medium'>No reviews yet</h1>
					)}
				</div>
				{reviews.length > 0 && (
					<div className='fade'>
						<Reviews reviews={reviewsToShow} />
					</div>
				)}

				{reviews.length > DEFAULT_NUM_REVIEWS_TO_SHOW && (
					<div className='w-full flex items-center justify-center'>
						{numReviewsToShow === DEFAULT_NUM_REVIEWS_TO_SHOW ? (
							<button
								className='p-1.5 bg-accent rounded-full hover:brightness-95 transition duration-200 ease-out fade'
								onClick={handleExpand}
							>
								<svg
									xmlns='http://www.w3.org/2000/svg'
									viewBox='0 0 24 24'
									fill='currentColor'
									className='w-6 h-6 text-white'
								>
									<path
										fillRule='evenodd'
										d='M20.03 4.72a.75.75 0 010 1.06l-7.5 7.5a.75.75 0 01-1.06 0l-7.5-7.5a.75.75 0 011.06-1.06L12 11.69l6.97-6.97a.75.75 0 011.06 0zm0 6a.75.75 0 010 1.06l-7.5 7.5a.75.75 0 01-1.06 0l-7.5-7.5a.75.75 0 111.06-1.06L12 17.69l6.97-6.97a.75.75 0 011.06 0z'
										clipRule='evenodd'
									/>
								</svg>
							</button>
						) : (
							<button
								className='p-1.5 bg-accent rounded-full hover:brightness-95 transition duration-200 ease-out fade'
								onClick={handleClose}
							>
								<svg
									xmlns='http://www.w3.org/2000/svg'
									viewBox='0 0 24 24'
									fill='currentColor'
									className='w-6 h-6 text-white'
								>
									<path
										fillRule='evenodd'
										d='M11.47 4.72a.75.75 0 011.06 0l7.5 7.5a.75.75 0 11-1.06 1.06L12 6.31l-6.97 6.97a.75.75 0 01-1.06-1.06l7.5-7.5zm.53 7.59l-6.97 6.97a.75.75 0 01-1.06-1.06l7.5-7.5a.75.75 0 011.06 0l7.5 7.5a.75.75 0 11-1.06 1.06L12 12.31z'
										clipRule='evenodd'
									/>
								</svg>
							</button>
						)}
					</div>
				)}
				<SimilarFilms
					filmId={filmDetails.filmId}
					genreId={filmDetails.genreId}
					directorId={filmDetails.directorId}
					genre={genre}
				/>
			</MainLayout>
		)
	}
	return null
}

export default ViewFilm
