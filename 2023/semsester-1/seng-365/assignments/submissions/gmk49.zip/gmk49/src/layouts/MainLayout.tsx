import { ReactNode } from 'react'
import Header from '../components/Header'

interface Props {
	children?: ReactNode
}

const MainLayout = ({ children }: Props) => {
	return (
		<>
			<Header />
			<div className='flex items-center justify-center mt-nav-height'>
				<div className='px-10 flex flex-col gap-5 py-5 w-full max-w-5xl'>{children}</div>
			</div>
		</>
	)
}

export default MainLayout
