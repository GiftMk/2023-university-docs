import defaultTheme from 'tailwindcss/defaultTheme'

/** @type {import('tailwindcss').Config} */
export default {
	content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
	theme: {
		extend: {
			spacing: {
				'nav-height': '4.5rem'
			},
			colors: {
				accent: '#DD682A'
			},
			borderRadius: {
				'3xl': '20px'
			},
			transitionDuration: {
				40: '40ms'
			},
			screens: {
				xs: '450px'
			},
			dropShadow: {
				lg: '0 13px 13px rgb(0 0 0 / 0.057)'
			}
		},
		fontFamily: {
			sans: ['Inter', ...defaultTheme.fontFamily.sans]
		}
	},
	plugins: []
}
